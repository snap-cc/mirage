void c_menu::draw_weapon_rage(rage_weapon_cfg_t* settings, const char* label) {
    if (!settings)
        return;

    ImGui::PushID(label);

    ImGui::Checkbox("Enabled", &settings->m_enabled);
    ImGui::Checkbox("Silent", &settings->m_silent);

    ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(0.10f, 0.10f, 0.12f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, ImVec4(0.12f, 0.12f, 0.14f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_FrameBgActive, ImVec4(0.14f, 0.14f, 0.16f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_PopupBg, ImVec4(0.08f, 0.08f, 0.10f, 0.94f));

    ImGui::MultiCombo("Hitboxes", settings->m_hitboxes, hitboxes, IM_ARRAYSIZE(hitboxes));
    ImGui::MultiCombo("Multi Points", settings->m_multi_points, multi_points, IM_ARRAYSIZE(multi_points));

    ImGui::PopStyleColor(4);

    if (settings->m_multi_points[0] || settings->m_multi_points[1] || settings->m_multi_points[2] || 
        settings->m_multi_points[3] || settings->m_multi_points[4] || settings->m_multi_points[5]) {
        ImGui::Checkbox("Static Scale", &settings->m_static_scale);

        if (settings->m_static_scale) {
            for (int i = 0; i < IM_ARRAYSIZE(multi_points); i++) {
                if (settings->m_multi_points[i]) {
                    ImGui::PushItemWidth(130);
                    ImGui::SliderFloat(std::format("{} Scale", hitboxes[i]).c_str(), &settings->m_hitbox_scale[i], 1.f, 100.f, "%.1f");
                    ImGui::PopItemWidth();
                }
            }
        }
    }

    ImGui::PushStyleColor(ImGuiCol_SliderGrab, ImVec4(0.0f, 0.8f, 1.0f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_SliderGrabActive, ImVec4(0.0f, 0.9f, 1.0f, 1.0f));

    ImGui::SliderInt("Minimum Damage", &settings->m_minimum_damage, 1, 100);
    ImGui::SliderInt("Hit Chance", &settings->m_hit_chance, 1, 100);
    ImGui::Checkbox("Auto Stop", &settings->m_auto_stop);

    ImGui::PopStyleColor(2);
    ImGui::PopID();
}
