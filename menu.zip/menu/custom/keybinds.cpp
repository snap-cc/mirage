#include "keybinds.hpp"
#include <algorithm>

// instantiate global pointer
c_keybinds_display* g_keybinds_display = nullptr;

std::vector<c_keybinds_display::keybind_t> c_keybinds_display::m_keybinds;
int c_keybinds_display::m_pos_x = 0;
int c_keybinds_display::m_pos_y = 0;
bool c_keybinds_display::m_initialized = false;

// create the instance at module load
struct _create_keybinds_instance {
    _create_keybinds_instance() {
        if (!g_keybinds_display)
            g_keybinds_display = new c_keybinds_display();
    }
} _create_keybinds_instance_global;

void c_keybinds_display::style_setup() {
    if (m_initialized) return;
    m_initialized = true;
}

void c_keybinds_display::push(const std::string& name, int mode) {
    // update existing or push new
    auto it = std::find_if(m_keybinds.begin(), m_keybinds.end(), [&](const keybind_t& k) { return k.name == name; });
    if (it != m_keybinds.end()) {
        it->mode = mode;
        return;
    }

    m_keybinds.push_back({ name, mode });
}

void c_keybinds_display::remove(const std::string& name) {
    m_keybinds.erase(std::remove_if(m_keybinds.begin(), m_keybinds.end(), [&](const keybind_t& k) { return k.name == name; }), m_keybinds.end());
}

void c_keybinds_display::render() {
    // minimal: no actual render here; other code expects these functions to exist
}

void c_keybinds_display::reset() {
    m_keybinds.clear();
    m_pos_x = m_pos_y = 0;
    m_initialized = false;
}
