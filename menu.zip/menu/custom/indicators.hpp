#pragma once

#include <string>

class c_indicators_display {
public:
    void render();
};

extern c_indicators_display* g_indicators_display;
