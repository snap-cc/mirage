#include "indicators.hpp"
#include "../menu.hpp"
#include "../../render/render.hpp"
#include "../../features/rage_bot/rage_bot.hpp"
#include "../../features/rage_bot/rage_settings.hpp"

// instantiate global pointer
c_indicators_display* g_indicators_display = nullptr;

struct _create_indicators_instance {
    _create_indicators_instance() {
        if (!g_indicators_display)
            g_indicators_display = new c_indicators_display();
    }
} _create_indicators_instance_global;

void c_indicators_display::render() {
    if (!g_cfg->misc.m_indicator_enabled)
        return;

    // position
    int x = g_cfg->misc.m_indicator_pos_x;
    int y = g_cfg->misc.m_indicator_pos_y;

    // prepare lines: show per-weapon min damage (and override if pressed)
    int display_min_dmg = g_cfg->rage_bot.m_minimum_damage;
    if (g_ctx && g_ctx->m_local_pawn) {
        if (auto active_weapon = g_ctx->m_local_pawn->get_active_weapon()) {
            const auto ws_pair = get_weapon_settings(active_weapon);
            const auto* weapon_settings = ws_pair.second;
            if (weapon_settings)
                display_min_dmg = weapon_settings->m_minimum_damage;

            if (g_key_handler && g_key_handler->is_pressed(g_cfg->rage_bot.m_override_damage_key_bind, g_cfg->rage_bot.m_override_damage_key_bind_style)) {
                if (weapon_settings && weapon_settings->m_override_damage > 0)
                    display_min_dmg = weapon_settings->m_override_damage;
                else
                    display_min_dmg = weapon_settings ? weapon_settings->m_minimum_damage_override : g_cfg->rage_bot.m_minimum_damage_override;
            }
        }
    }

    std::string min_dmg = std::format("Min dmg: {0}", display_min_dmg);

    // manual left/right keys / toggles
    bool manual_left = false;
    bool manual_right = false;

    // prefer keybinds if set
    if (g_cfg->anti_hit.m_manual_left_key != 0)
        manual_left = g_cfg->anti_hit.m_manual_left_key != 0;
    else
        manual_left = g_cfg->anti_hit.m_manual_left;

    if (g_cfg->anti_hit.m_manual_right_key != 0)
        manual_right = g_cfg->anti_hit.m_manual_right_key != 0;
    else
        manual_right = g_cfg->anti_hit.m_manual_right;

    std::string manual_txt = std::format("Manual: {0}{1}", manual_left ? "L" : "", manual_right ? "R" : "");

    // draw background box (extended vertically)
    g_render->rect({(float)x - 6.f, (float)y - 6.f, 0.f}, {(float)x + 180.f, (float)y + 64.f, 0.f}, {0.f, 0.f, 0.f, 0.5f}, 4.f);

    // draw texts (shifted down)
    g_render->text({(float)x, (float)y + 4.f, 0.f}, {1.f, 1.f, 1.f, 1.f}, 0, g_render->fonts.verdana, min_dmg, 13);
    g_render->text({(float)x, (float)y + 24.f, 0.f}, {1.f, 1.f, 1.f, 1.f}, 0, g_render->fonts.verdana, manual_txt, 13);

    // FORCE SHOT indicator (red) when bind is held
    if (g_key_handler && g_key_handler->is_pressed(g_cfg->rage_bot.m_force_shot_key_bind, g_cfg->rage_bot.m_force_shot_key_bind_style)) {
        // use available font (verdana) and correct param order for c_render::text
    g_render->text({(float)x, (float)y + 44.f, 0.f}, {1.f, 0.f, 0.f, 1.f}, 0, g_render->fonts.verdana, "FORCE SHOT", 14);
    }
}
