const char* weapon_category_names[] = {
    "Heavy Pistols",
    "Pistols",
    "Rifles",
    "Scout",
    "AWP", 
    "Auto-Snipers"
};
