#include "menu.hpp"
#include "../darkside.hpp"
#include "../utils/hwid.hpp"
#include <Windows.h>
#include <future>
#include <atomic>
#include "../features/skins/skins.hpp"
#include <string>

// Статические переменные для кастомизации цвета и прозрачности
static float g_menu_red_color[4] = { 1.0f, 0.0f, 0.0f, 1.0f }; 
static float g_menu_opacity = 0.90f;

void c_menu::draw() {
    if (!m_opened)
        return;

    // Установка стиля GameSens (острые углы, тонкие границы)
    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowPadding = ImVec2(0, 0);
    style.WindowRounding = 0.0f;
    style.ChildRounding = 0.0f;
    style.FrameRounding = 0.0f;
    style.ScrollbarRounding = 0.0f;
    style.GrabRounding = 0.0f;
    style.WindowBorderSize = 1.0f;
    style.ItemSpacing = ImVec2(8, 8);

    // Определение основных цветов на основе выбора пользователя
    ImVec4 main_accent = ImVec4(g_menu_red_color[0], g_menu_red_color[1], g_menu_red_color[2], 1.0f);
    ImVec4 bg_color = ImVec4(0.05f, 0.05f, 0.05f, g_menu_opacity);

    // Применение цветовой схемы
    ImGui::PushStyleColor(ImGuiCol_WindowBg, bg_color);
    ImGui::PushStyleColor(ImGuiCol_Border, main_accent);
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.07f, 0.07f, 0.07f, 0.0f));
    ImGui::PushStyleColor(ImGuiCol_Header, ImVec4(0.10f, 0.10f, 0.10f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_HeaderHovered, ImVec4(0.13f, 0.13f, 0.13f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_HeaderActive, main_accent);
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.10f, 0.10f, 0.10f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, main_accent);
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, main_accent);
    ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(0.12f, 0.12f, 0.12f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_CheckMark, main_accent);
    ImGui::PushStyleColor(ImGuiCol_SliderGrab, main_accent);
    ImGui::PushStyleColor(ImGuiCol_SliderGrabActive, main_accent);

    ImGui::SetNextWindowSize(ImVec2(660.0f, 500.0f), ImGuiCond_Once);

    // Название меню изменено на GAMESENS
    if (ImGui::Begin("GAMESENS", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoTitleBar)) {
        ImVec2 p = ImGui::GetWindowPos();
        ImVec2 s = ImGui::GetWindowSize();

        // Верхняя декоративная полоса (фирменный стиль)
        ImGui::GetWindowDrawList()->AddRectFilled(p, ImVec2(p.x + s.x, p.y + 2), ImGui::GetColorU32(main_accent));

        // Левая панель вкладок (Sidebar)
        ImGui::BeginChild("tabs_sidebar", ImVec2(130, 0), true);
        {
            const char* tabs[] = { 
                ICON_FA_BULLSEYE " Rage", 
                ICON_FA_USER " Anti-Hit", 
                ICON_FA_EYE " Visuals", 
                ICON_FA_SHIELD_ALT " Player", 
                ICON_FA_COG " Other", 
                ICON_FA_PALETTE " Skins", 
                ICON_FA_REDO " Config" 
            };

            for (int i = 0; i < IM_ARRAYSIZE(tabs); i++) {
                bool selected = (m_selected_tab == i);
                if (selected) ImGui::PushStyleColor(ImGuiCol_Text, main_accent);

                if (ImGui::Button(tabs[i], ImVec2(130, 40)))
                    m_selected_tab = i;

                if (selected) ImGui::PopStyleColor();
            }
        }
        ImGui::EndChild();

        ImGui::SameLine();

        // Основная рабочая область
        ImGui::BeginChild("main_content", ImVec2(0, 0), false);
        {
            ImGui::SetCursorPos(ImVec2(15, 15));
            
            if (m_selected_tab == 0) { // RageBot
                ImGui::Text("RAGEBOT");
                ImGui::Separator();
                ImGui::Checkbox("Master Switch", &g_cfg->rage_bot.m_enabled);
                // Здесь можно вызвать c_menu::draw_weapon_rage
            }
            else if (m_selected_tab == 4) { // Other / Настройки меню
                ImGui::Text("MENU SETTINGS");
                ImGui::Separator();
                
                // Настройка прозрачности и цвета
                ImGui::SliderFloat("Menu Opacity", &g_menu_opacity, 0.1f, 1.0f);
                ImGui::ColorEdit4("Accent Color", g_menu_red_color, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
                
                ImGui::Separator();
                ImGui::Checkbox("Auto Peek", &g_cfg->misc.m_auto_peek);
                ImGui::Checkbox("Chat Spam", &g_cfg->misc.m_chat_spam);
                ImGui::Checkbox("Hide Console", &g_cfg->misc.m_hide_console);
            }
            else if (m_selected_tab == 6) { // Configs
                g_config_system->menu();
            }
        }
        ImGui::EndChild();
    }
    ImGui::End();

    ImGui::PopStyleColor(13);
}

void c_menu::on_create_move() {
    if (!m_opened)
        return;

    g_ctx->m_user_cmd->m_button_state.m_button_state &= ~(IN_ATTACK | IN_ATTACK2);
    g_ctx->m_user_cmd->m_button_state.m_button_state2 &= ~(IN_ATTACK | IN_ATTACK2);
    g_ctx->m_user_cmd->m_button_state.m_button_state3 &= ~(IN_ATTACK | IN_ATTACK2);
}
