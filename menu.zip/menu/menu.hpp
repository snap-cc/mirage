#pragma once

#include <memory>
#include <string>
#include "../sdk/includes/imgui/imgui.h"
#include "font_awesome_icons.hpp"

class c_menu {
	int m_selected_tab{ };
public:
	bool m_opened;

	void draw( );
	void on_create_move( );

private:
    void DrawModernCheckbox(const char* label, bool* value);
    void DrawModernSlider(const char* label, int* value, int min, int max);
    void DrawModernCombo(const char* label, int* current_item, const char* const* items, int items_count);
    void DrawModernColorPicker(const char* label, float* col, int flags = 0);
};

inline const auto g_menu = std::make_unique<c_menu>( );